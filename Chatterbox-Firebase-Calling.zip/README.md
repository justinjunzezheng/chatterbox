# Chatterbox — Firebase edition

A real-time browser messenger using Firebase Authentication, Cloud Firestore,
WebRTC and Firebase Hosting.

## Included

- Separate email/password and Google accounts
- Real-time direct messages and group conversations
- Voice and video calls
- Group calling with multiple participants
- Incoming-call notifications, mute, camera and screen-sharing controls
- Shared Community Lounge
- Photo and PDF attachments
- Stories that disappear from the app after 24 hours
- Replies and emoji reactions
- Desktop and mobile layouts
- Firebase security rules
- A production Firebase Hosting configuration

## Connect your Firebase project

1. Open https://console.firebase.google.com and create a project.
2. Add a Web app from Project settings.
3. Copy `.env.example` to `.env`.
4. Paste the six values from the Firebase web configuration into `.env`.
5. In Authentication → Sign-in method, enable Email/Password and Google.
6. Create a Cloud Firestore database.
7. Cloud Storage is optional and is needed only for photo and file uploads.
8. Copy `.firebaserc.example` to `.firebaserc` and replace the sample project ID.

## Test

Run `npm install`, followed by `npm run dev`.

## Deploy

1. Run `npx firebase login`.
2. Run `npm run build`.
3. Run `npx firebase deploy --only hosting,firestore:rules`.

Calls use WebRTC for live audio/video and Firestore for secure call signalling.
Allow camera and microphone access when your browser asks. For a large public
service, add a dedicated TURN server later so calls also connect on restrictive
networks.

Firebase will provide both `https://YOUR_PROJECT_ID.web.app` and
`https://YOUR_PROJECT_ID.firebaseapp.com`. You can also connect a custom domain.

## Security

The included rules require authentication. Users may update only their own
profiles and uploads. Messages are readable only by conversation members.
Do not replace these rules with open test rules in production.
