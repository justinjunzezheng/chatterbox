import { useEffect, useRef, useState } from "react";
import { User } from "firebase/auth";
import {
  addDoc, arrayUnion, collection, deleteDoc, doc, getDoc, onSnapshot, query,
  serverTimestamp, setDoc, updateDoc, where,
} from "firebase/firestore";
import { db } from "./firebase";

export type CallConversation = {
  id: string;
  title: string;
  kind: "group" | "dm";
  memberIds: string[];
};

export type CallRequest = {
  conversation: CallConversation;
  mode: "audio" | "video";
};

type CallDoc = {
  conversationId: string;
  title: string;
  callerId: string;
  callerName: string;
  memberIds: string[];
  mode: "audio" | "video";
  status: "ringing" | "active" | "ended";
};

type Signal = {
  id: string;
  from: string;
  to: string;
  kind: "offer" | "answer" | "candidate";
  description?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
};

const rtcConfig: RTCConfiguration = {
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

export default function CallSystem({
  user, request, onRequestHandled,
}: {
  user: User;
  request: CallRequest | null;
  onRequestHandled: () => void;
}) {
  const [incoming, setIncoming] = useState<{ id: string; data: CallDoc } | null>(null);
  const [callId, setCallId] = useState("");
  const [call, setCall] = useState<CallDoc | null>(null);
  const [status, setStatus] = useState("Connecting…");
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [error, setError] = useState("");
  const localVideo = useRef<HTMLVideoElement>(null);
  const localStream = useRef<MediaStream | null>(null);
  const peers = useRef(new Map<string, RTCPeerConnection>());
  const remoteStreams = useRef(new Map<string, MediaStream>());
  const processedSignals = useRef(new Set<string>());
  const declinedCalls = useRef(new Set<string>());
  const queuedCandidates = useRef(new Map<string, RTCIceCandidateInit[]>());
  const [remoteVersion, setRemoteVersion] = useState(0);

  useEffect(() => {
    const q = query(collection(db, "calls"), where("memberIds", "array-contains", user.uid));
    return onSnapshot(q, snap => {
      const found = snap.docs
        .map(d => ({ id: d.id, data: d.data() as CallDoc }))
        .find(x => x.data.callerId !== user.uid && !declinedCalls.current.has(x.id) && (x.data.status === "ringing" || x.data.status === "active"));
      if (found && !callId) setIncoming(found);
    });
  }, [user.uid, callId]);

  useEffect(() => {
    if (!request || callId) return;
    void startCall(request);
    onRequestHandled();
  }, [request, callId]);

  useEffect(() => {
    if (!callId) return;
    const stopCall = onSnapshot(doc(db, "calls", callId), snap => {
      if (!snap.exists()) return void finishLocally();
      const data = snap.data() as CallDoc;
      setCall(data);
      setStatus(data.status === "ringing" ? "Ringing…" : "In call");
      if (data.status === "ended") finishLocally();
    });
    const stopParticipants = onSnapshot(collection(db, "calls", callId, "participants"), snap => {
      const ids = snap.docs.map(d => d.id).filter(id => id !== user.uid);
      ids.forEach(id => void ensurePeer(id));
      for (const [id, pc] of peers.current) {
        if (!ids.includes(id)) {
          pc.close(); peers.current.delete(id); remoteStreams.current.delete(id);
        }
      }
      setRemoteVersion(x => x + 1);
    });
    const signalQuery = query(collection(db, "calls", callId, "signals"), where("to", "==", user.uid));
    const stopSignals = onSnapshot(signalQuery, snap => {
      snap.docChanges().filter(c => c.type === "added").forEach(c => {
        const signal = { id: c.doc.id, ...c.doc.data() } as Signal;
        if (!processedSignals.current.has(signal.id)) void handleSignal(signal);
      });
    });
    return () => { stopCall(); stopParticipants(); stopSignals(); };
  }, [callId, user.uid]);

  useEffect(() => {
    if (localVideo.current) localVideo.current.srcObject = localStream.current;
  }, [callId, cameraOff]);

  async function openMedia(mode: "audio" | "video") {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Calls are not supported in this browser.");
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true },
      video: mode === "video" ? { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } } : false,
    });
    localStream.current = stream;
    return stream;
  }

  async function startCall(next: CallRequest) {
    setError("");
    try {
      await openMedia(next.mode);
      const created = await addDoc(collection(db, "calls"), {
        conversationId: next.conversation.id,
        title: next.conversation.title,
        callerId: user.uid,
        callerName: user.displayName || user.email || "Someone",
        memberIds: next.conversation.memberIds,
        joinedIds: [user.uid],
        mode: next.mode,
        status: "ringing",
        createdAt: serverTimestamp(),
      });
      setCallId(created.id);
      setCall({
        conversationId: next.conversation.id, title: next.conversation.title,
        callerId: user.uid, callerName: user.displayName || "You",
        memberIds: next.conversation.memberIds, mode: next.mode, status: "ringing",
      });
      await setDoc(doc(db, "calls", created.id, "participants", user.uid), {
        uid: user.uid, displayName: user.displayName || "You", joinedAt: serverTimestamp(),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not start the call.");
      stopMedia();
    }
  }

  async function answer() {
    if (!incoming) return;
    setError("");
    try {
      await openMedia(incoming.data.mode);
      setCallId(incoming.id); setCall(incoming.data); setIncoming(null);
      await setDoc(doc(db, "calls", incoming.id, "participants", user.uid), {
        uid: user.uid, displayName: user.displayName || "User", joinedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, "calls", incoming.id), {
        status: "active", joinedIds: arrayUnion(user.uid),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Camera or microphone permission was denied.");
      stopMedia();
    }
  }

  async function decline() {
    if (!incoming) return;
    declinedCalls.current.add(incoming.id);
    await setDoc(doc(db, "calls", incoming.id, "declines", user.uid), {
      uid: user.uid, declinedAt: serverTimestamp(),
    });
    setIncoming(null);
  }

  async function ensurePeer(remoteId: string) {
    if (peers.current.has(remoteId) || !callId || !localStream.current) return peers.current.get(remoteId);
    const pc = new RTCPeerConnection(rtcConfig);
    peers.current.set(remoteId, pc);
    localStream.current.getTracks().forEach(track => pc.addTrack(track, localStream.current!));
    pc.onicecandidate = e => {
      if (e.candidate) void sendSignal(remoteId, "candidate", { candidate: e.candidate.toJSON() });
    };
    pc.ontrack = e => {
      const stream = e.streams[0] || remoteStreams.current.get(remoteId) || new MediaStream();
      if (!e.streams[0]) stream.addTrack(e.track);
      remoteStreams.current.set(remoteId, stream);
      setRemoteVersion(x => x + 1);
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") setStatus("In call");
      if (["failed", "disconnected"].includes(pc.connectionState)) setStatus("Reconnecting…");
    };
    if (user.uid < remoteId) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await sendSignal(remoteId, "offer", { description: offer });
    }
    return pc;
  }

  async function sendSignal(to: string, kind: Signal["kind"], payload: Partial<Signal>) {
    if (!callId) return;
    await addDoc(collection(db, "calls", callId, "signals"), {
      from: user.uid, to, kind, ...payload, createdAt: serverTimestamp(),
    });
  }

  async function handleSignal(signal: Signal) {
    processedSignals.current.add(signal.id);
    const pc = await ensurePeer(signal.from);
    if (!pc) return;
    if (signal.kind === "offer" && signal.description) {
      await pc.setRemoteDescription(signal.description);
      const answerDescription = await pc.createAnswer();
      await pc.setLocalDescription(answerDescription);
      await sendSignal(signal.from, "answer", { description: answerDescription });
      await flushCandidates(signal.from, pc);
    } else if (signal.kind === "answer" && signal.description) {
      await pc.setRemoteDescription(signal.description);
      await flushCandidates(signal.from, pc);
    } else if (signal.kind === "candidate" && signal.candidate) {
      if (pc.remoteDescription) await pc.addIceCandidate(signal.candidate);
      else queuedCandidates.current.set(signal.from, [...(queuedCandidates.current.get(signal.from) || []), signal.candidate]);
    }
    if (callId) await deleteDoc(doc(db, "calls", callId, "signals", signal.id)).catch(() => undefined);
  }

  async function flushCandidates(remoteId: string, pc: RTCPeerConnection) {
    for (const candidate of queuedCandidates.current.get(remoteId) || []) await pc.addIceCandidate(candidate);
    queuedCandidates.current.delete(remoteId);
  }

  function toggleMute() {
    const next = !muted;
    localStream.current?.getAudioTracks().forEach(t => { t.enabled = !next; });
    setMuted(next);
  }

  function toggleCamera() {
    const next = !cameraOff;
    localStream.current?.getVideoTracks().forEach(t => { t.enabled = !next; });
    setCameraOff(next);
  }

  async function toggleScreen() {
    if (sharing) {
      const camera = localStream.current?.getVideoTracks()[0];
      if (camera) for (const pc of peers.current.values()) {
        const sender = pc.getSenders().find(s => s.track?.kind === "video");
        if (sender) await sender.replaceTrack(camera);
      }
      setSharing(false); return;
    }
    try {
      const display = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const screenTrack = display.getVideoTracks()[0];
      for (const pc of peers.current.values()) {
        const sender = pc.getSenders().find(s => s.track?.kind === "video");
        if (sender) await sender.replaceTrack(screenTrack);
      }
      screenTrack.onended = () => { setSharing(false); };
      setSharing(true);
    } catch { /* The user cancelled the picker. */ }
  }

  async function leave() {
    if (callId) {
      await deleteDoc(doc(db, "calls", callId, "participants", user.uid)).catch(() => undefined);
      if (call?.callerId === user.uid) await updateDoc(doc(db, "calls", callId), { status: "ended", endedAt: serverTimestamp() }).catch(() => undefined);
    }
    finishLocally();
  }

  function stopMedia() {
    localStream.current?.getTracks().forEach(t => t.stop());
    localStream.current = null;
  }

  function finishLocally() {
    stopMedia();
    peers.current.forEach(pc => pc.close());
    peers.current.clear(); remoteStreams.current.clear(); processedSignals.current.clear(); queuedCandidates.current.clear();
    setCallId(""); setCall(null); setStatus("Connecting…"); setMuted(false); setCameraOff(false); setSharing(false);
  }

  const remotes = [...remoteStreams.current.entries()];
  void remoteVersion;

  return <>
    {incoming && !callId && <div className="incoming-call">
      <div className="call-pulse">☎</div>
      <div><small>Incoming {incoming.data.mode} call</small><h3>{incoming.data.title}</h3><p>{incoming.data.callerName} is calling</p></div>
      <button className="decline-call" onClick={decline}>✕</button>
      <button className="answer-call" onClick={answer}>☎</button>
    </div>}
    {callId && call && <div className="call-screen">
      <header><div><small>{call.mode === "video" ? "VIDEO CALL" : "VOICE CALL"}</small><h2>{call.title}</h2><p>{status} · {remotes.length + 1} participant{remotes.length ? "s" : ""}</p></div></header>
      <div className={`video-grid count-${Math.min(remotes.length + 1, 4)}`}>
        <CallTile stream={localStream.current} video={call.mode === "video" && !cameraOff} muted label="You"/>
        {remotes.map(([id, stream]) => <CallTile key={id} stream={stream} video={call.mode === "video"} label="Participant"/>)}
        {remotes.length === 0 && <div className="waiting-call"><span>☎</span><b>Waiting for others to join…</b><small>They will see an incoming call notification.</small></div>}
      </div>
      <footer className="call-controls">
        <button className={muted ? "off" : ""} onClick={toggleMute}><span>{muted ? "♩" : "🎙"}</span><small>{muted ? "Unmute" : "Mute"}</small></button>
        {call.mode === "video" && <button className={cameraOff ? "off" : ""} onClick={toggleCamera}><span>▣</span><small>{cameraOff ? "Camera on" : "Camera off"}</small></button>}
        {call.mode === "video" && <button className={sharing ? "active" : ""} onClick={toggleScreen}><span>▱</span><small>{sharing ? "Stop sharing" : "Share screen"}</small></button>}
        <button className="hangup" onClick={leave}><span>☎</span><small>Leave</small></button>
      </footer>
    </div>}
    {error && <div className="call-error">{error}<button onClick={() => setError("")}>×</button></div>}
  </>;
}

function CallTile({ stream, video, muted = false, label }: { stream: MediaStream | null; video: boolean; muted?: boolean; label: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => { if (ref.current) ref.current.srcObject = stream; }, [stream]);
  return <div className="call-tile">
    <video ref={ref} autoPlay playsInline muted={muted} className={video ? "" : "audio-only"}/>
    {!video && <div className="audio-avatar">◉</div>}
    <span>{label}</span>
  </div>;
}
