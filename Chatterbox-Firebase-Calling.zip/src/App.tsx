import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  User, createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signInWithPopup, signOut, updateProfile,
} from "firebase/auth";
import {
  Timestamp, addDoc, arrayRemove, arrayUnion, collection, deleteField, doc, getDoc, getDocs,
  limit, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc, where,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { auth, db, googleProvider, isConfigured, storage } from "./firebase";
import CallSystem, { CallRequest } from "./Calls";

type Person = { uid: string; displayName: string; email: string; photoURL?: string; lastSeen?: Timestamp };
type Conversation = { id: string; title: string; kind: "group" | "dm"; memberIds: string[]; lastMessage?: string; updatedAt?: Timestamp; createdBy: string };
type Message = { id: string; senderId: string; senderName: string; body: string; imageUrl?: string; fileUrl?: string; replyToId?: string; replyText?: string; reactions?: string[]; createdAt?: Timestamp };
type Story = { id: string; authorId: string; authorName: string; imageUrl: string; createdAt?: Timestamp };

const initials = (name = "?") => name.split(/\s+/).map(x => x[0]).join("").slice(0, 2).toUpperCase();
const hue = (text = "") => [...text].reduce((n, c) => n + c.charCodeAt(0), 0) % 360;

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [error, setError] = useState("");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [activeId, setActiveId] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState("");
  const [search, setSearch] = useState("");
  const [reply, setReply] = useState<Message | null>(null);
  const [modal, setModal] = useState<"new" | "people" | "story" | null>(null);
  const [storyView, setStoryView] = useState<Story | null>(null);
  const [groupName, setGroupName] = useState("");
  const [selectedPeople, setSelectedPeople] = useState<string[]>([]);
  const [mobilePanel, setMobilePanel] = useState<"list" | "chat" | "info">("list");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [callRequest, setCallRequest] = useState<CallRequest | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isConfigured) { setAuthReady(true); return; }
    return onAuthStateChanged(auth, async current => {
    setUser(current); setAuthReady(true);
    if (current) {
      await setDoc(doc(db, "users", current.uid), {
        uid: current.uid, displayName: current.displayName || current.email?.split("@")[0] || "User",
        email: current.email || "", photoURL: current.photoURL || "", lastSeen: serverTimestamp(),
      }, { merge: true });
      await setDoc(doc(db, "conversations", "community-lounge"), {
        title: "Community Lounge", kind: "group", createdBy: "system",
        memberIds: arrayUnion(current.uid), updatedAt: serverTimestamp(), lastMessage: "Welcome to Chatterbox",
      }, { merge: true });
    } else { setConversations([]); setMessages([]); }
    });
  }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "conversations"), where("memberIds", "array-contains", user.uid));
    return onSnapshot(q, snap => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as Conversation))
        .sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0));
      setConversations(list); setActiveId(old => old || list[0]?.id || "");
    }, e => setError(e.message));
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const stopUsers = onSnapshot(collection(db, "users"), snap => setPeople(snap.docs.map(d => d.data() as Person).filter(p => p.uid !== user.uid)));
    const q = query(collection(db, "stories"), orderBy("createdAt", "desc"), limit(30));
    const stopStories = onSnapshot(q, snap => setStories(snap.docs.map(d => ({ id: d.id, ...d.data() } as Story)).filter(s => !s.createdAt || Date.now() - s.createdAt.toMillis() < 86400000)));
    return () => { stopUsers(); stopStories(); };
  }, [user]);

  useEffect(() => {
    if (!activeId) return setMessages([]);
    const q = query(collection(db, "conversations", activeId, "messages"), orderBy("createdAt", "asc"), limit(250));
    return onSnapshot(q, snap => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as Message)));
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 30);
    }, e => setError(e.message));
  }, [activeId]);

  const active = conversations.find(c => c.id === activeId);
  const filtered = useMemo(() => conversations.filter(c => (c.title + " " + (c.lastMessage || "")).toLowerCase().includes(search.toLowerCase())), [conversations, search]);
  const memberPeople = active?.memberIds.map(id => id === user?.uid ? ({ uid: user.uid, displayName: user.displayName || "You", email: user.email || "", photoURL: user.photoURL || "" } as Person) : people.find(p => p.uid === id)).filter(Boolean) as Person[] || [];

  async function authenticate(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      if (authMode === "signup") {
        const result = await createUserWithEmailAndPassword(auth, authEmail, authPassword);
        await updateProfile(result.user, { displayName: authName.trim() || authEmail.split("@")[0] });
        await result.user.reload(); setUser(auth.currentUser);
      } else await signInWithEmailAndPassword(auth, authEmail, authPassword);
    } catch (e) { setError(e instanceof Error ? e.message.replace("Firebase: ", "") : "Could not sign in"); }
    setBusy(false);
  }
  async function googleSignIn() {
    setError(""); try { await signInWithPopup(auth, googleProvider); } catch (e) { setError(e instanceof Error ? e.message : "Google sign-in failed"); }
  }
  async function send(e?: FormEvent) {
    e?.preventDefault(); if (!user || !activeId || !draft.trim() || busy) return;
    const body = draft.trim(); setDraft(""); setBusy(true);
    await addDoc(collection(db, "conversations", activeId, "messages"), {
      senderId: user.uid, senderName: user.displayName || user.email || "User", body,
      replyToId: reply?.id || null, replyText: reply?.body || null, reactions: [], createdAt: serverTimestamp(),
    });
    await updateDoc(doc(db, "conversations", activeId), { lastMessage: body, updatedAt: serverTimestamp() });
    setReply(null); setBusy(false);
  }
  async function upload(file: File, story = false) {
    if (!user || (!activeId && !story)) return; setBusy(true);
    try {
      const path = `users/${user.uid}/${story ? "stories" : "messages"}/${Date.now()}-${file.name.replace(/[^a-z0-9._-]/gi, "_")}`;
      const target = ref(storage, path); await uploadBytes(target, file); const url = await getDownloadURL(target);
      if (story) await addDoc(collection(db, "stories"), { authorId: user.uid, authorName: user.displayName || "User", imageUrl: url, createdAt: serverTimestamp() });
      else {
        await addDoc(collection(db, "conversations", activeId, "messages"), {
          senderId: user.uid, senderName: user.displayName || "User", body: draft.trim(),
          imageUrl: file.type.startsWith("image/") ? url : null, fileUrl: file.type.startsWith("image/") ? null : url,
          reactions: [], createdAt: serverTimestamp(),
        });
        await updateDoc(doc(db, "conversations", activeId), { lastMessage: file.type.startsWith("image/") ? "📷 Photo" : "📎 File", updatedAt: serverTimestamp() });
        setDraft("");
      }
      setModal(null);
    } catch (e) { setError(e instanceof Error ? e.message : "Upload failed"); }
    setBusy(false);
  }
  async function react(m: Message, emoji: string) {
    if (!user || !activeId) return; const token = `${user.uid}|${emoji}`; const has = (m.reactions || []).includes(token);
    await updateDoc(doc(db, "conversations", activeId, "messages", m.id), { reactions: has ? arrayRemove(token) : arrayUnion(token) });
  }
  async function createGroup() {
    if (!user || !groupName.trim()) return;
    const newDoc = await addDoc(collection(db, "conversations"), {
      title: groupName.trim(), kind: "group", createdBy: user.uid,
      memberIds: [user.uid, ...selectedPeople], lastMessage: "Group created", updatedAt: serverTimestamp(),
    });
    setGroupName(""); setSelectedPeople([]); setModal(null); setActiveId(newDoc.id);
  }
  async function startDm(person: Person) {
    if (!user) return;
    const existing = conversations.find(c => c.kind === "dm" && c.memberIds.includes(person.uid));
    if (existing) { setActiveId(existing.id); setModal(null); return; }
    const newDoc = await addDoc(collection(db, "conversations"), {
      title: person.displayName, kind: "dm", createdBy: user.uid, memberIds: [user.uid, person.uid], lastMessage: "Start chatting", updatedAt: serverTimestamp(),
    });
    setActiveId(newDoc.id); setModal(null);
  }
  const reactionGroups = (r: string[] = []) => Object.entries(r.reduce<Record<string, number>>((a, token) => { const emoji = token.split("|")[1]; a[emoji] = (a[emoji] || 0) + 1; return a; }, {}));

  if (!authReady) return <div className="loading-screen"><Logo/><h1>Chatterbox</h1><p>Loading…</p></div>;
  if (!isConfigured) return <SetupNeeded/>;
  if (!user) return <div className="auth-screen"><section className="auth-card">
    <Logo/><h1>Welcome to Chatterbox</h1><p>Private messages, groups and stories across all your devices.</p>
    <form onSubmit={authenticate}>
      {authMode === "signup" && <label>Display name<input value={authName} onChange={e => setAuthName(e.target.value)} required placeholder="Your name"/></label>}
      <label>Email address<input type="email" value={authEmail} onChange={e => setAuthEmail(e.target.value)} required placeholder="you@example.com"/></label>
      <label>Password<input type="password" value={authPassword} onChange={e => setAuthPassword(e.target.value)} required minLength={6} placeholder="At least 6 characters"/></label>
      {error && <div className="auth-error">{error}</div>}
      <button className="auth-primary" disabled={busy}>{busy ? "Please wait…" : authMode === "signin" ? "Sign in" : "Create account"}</button>
    </form>
    <div className="auth-divider"><span>or</span></div>
    <button className="google-button" onClick={googleSignIn}>G&nbsp;&nbsp; Continue with Google</button>
    <button className="auth-switch" onClick={() => { setAuthMode(x => x === "signin" ? "signup" : "signin"); setError(""); }}>
      {authMode === "signin" ? "New here? Create an account" : "Already have an account? Sign in"}
    </button>
  </section></div>;

  return <main className="chat-app">
    <header className="topbar"><button className="brand" onClick={() => setMobilePanel("list")}><Logo/><b>Chatterbox</b></button>
      <label className="global-search"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search conversations"/></label>
      <div className="top-actions"><div className="mini-profile"><Avatar person={{ uid:user.uid,displayName:user.displayName||"User",email:user.email||"" }}/><span><b>{user.displayName}</b><small>Online</small></span></div><button title="Sign out" onClick={() => signOut(auth)}>↪</button></div>
    </header>
    <aside className={`sidebar ${mobilePanel === "list" ? "mobile-show" : ""}`}>
      <div className="side-heading"><div><h2>Messages</h2><p>Your private conversations</p></div><button className="compose" onClick={() => setModal("new")}>＋</button></div>
      <div className="stories"><button className="story add-story" onClick={() => setModal("story")}><span>＋</span><small>Your story</small></button>
        {stories.slice(0,5).map(s=><button className="story" key={s.id} onClick={()=>setStoryView(s)}><span className="story-ring"><Avatar person={{uid:s.authorId,displayName:s.authorName,email:s.authorId}}/></span><small>{s.authorName.split(" ")[0]}</small></button>)}
      </div>
      <label className="side-search"><span>⌕</span><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search or filter"/></label>
      <div className="filter-tabs"><button className="active">All</button><button>Unread</button><button>Groups</button></div>
      <div className="chat-list"><p className="eyebrow">CONVERSATIONS</p>{filtered.map(c=><button key={c.id} className={activeId===c.id?"active":""} onClick={()=>{setActiveId(c.id);setMobilePanel("chat")}}>
        <span className={`list-avatar ${c.kind}`}>{c.kind==="group"?"#":initials(c.title)}</span><span><b>{c.title}</b><small>{c.lastMessage||"Start chatting"}</small></span><time>{c.kind==="dm"?"•":""}</time></button>)}
        <button className="find-people" onClick={()=>setModal("people")}>＋ Find people on Chatterbox</button></div>
      <div className="account-card"><Avatar person={{uid:user.uid,displayName:user.displayName||"User",email:user.email||""}}/><span><b>{user.displayName}</b><small>{user.email}</small></span></div>
    </aside>
    <section className={`conversation ${mobilePanel==="chat"?"mobile-show":""}`}>{active?<><header className="conversation-head"><button className="mobile-back" onClick={()=>setMobilePanel("list")}>‹</button>
      <span className={`room-avatar ${active.kind}`}>{active.kind==="group"?"#":initials(active.title)}</span><div><h2>{active.title}</h2><p>{active.kind==="group"?`${active.memberIds.length} members`:"Online"}</p></div>
      <nav><button title="Start voice call" onClick={()=>setCallRequest({conversation:active,mode:"audio"})}>☎</button><button title="Start video call" onClick={()=>setCallRequest({conversation:active,mode:"video"})}>▣</button><button onClick={()=>setMobilePanel("info")}>ⓘ</button></nav></header>
      <div className="message-scroll"><div className="date-divider"><span>Today</span></div>{messages.length===0&&<div className="empty-chat"><span>✦</span><h3>Start the conversation</h3><p>New messages appear instantly on every signed-in device.</p></div>}
        {messages.map((m,i)=>{const mine=m.senderId===user.uid;return <article className={`message ${mine?"mine":""}`} key={m.id}><Avatar person={{uid:m.senderId,displayName:m.senderName,email:m.senderId}}/><div className="message-content">
          <div className="message-meta"><b>{mine?"You":m.senderName}</b><time>{m.createdAt?.toDate().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})||"sending…"}</time></div>
          {m.replyText&&<div className="reply-quote"><b>Reply</b><span>{m.replyText}</span></div>}<div className="bubble">{m.imageUrl&&<img src={m.imageUrl} alt="Shared"/>}{m.fileUrl&&<a className="file-card" href={m.fileUrl} target="_blank">▤ <span><b>Shared file</b><small>Tap to open</small></span></a>}{m.body&&<p>{m.body}</p>}</div>
          <div className="message-tools"><button onClick={()=>react(m,"❤️")}>♡</button><button onClick={()=>react(m,"👍")}>👍</button><button onClick={()=>setReply(m)}>↩ Reply</button></div>
          {(m.reactions?.length||0)>0&&<div className="reaction-row">{reactionGroups(m.reactions).map(([emoji,count])=><button key={emoji} onClick={()=>react(m,emoji)}>{emoji} {count}</button>)}</div>}
          {mine&&i===messages.length-1&&<small className="read-state">Delivered ✓✓</small>}</div></article>})}<div ref={endRef}/></div>
      <form className="composer" onSubmit={send}>{reply&&<div className="replying"><span><b>Replying to {reply.senderName}</b>{reply.body||"Photo"}</span><button type="button" onClick={()=>setReply(null)}>×</button></div>}
        <label className="attach">⌕<input type="file" accept="image/*,.pdf" onChange={e=>e.target.files?.[0]&&upload(e.target.files[0])}/></label><button type="button" className="emoji" onClick={()=>setDraft(x=>x+" 😊")}>☺</button>
        <textarea value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}} placeholder={`Message ${active.title}`} rows={1}/><span className="send-hint">Enter to send</span><button className="send" disabled={!draft.trim()||busy}>➤</button></form>
    </>:<div className="empty-chat"><h3>Select a conversation</h3></div>}</section>
    <aside className={`details ${mobilePanel==="info"?"mobile-show":""}`}><header><button className="mobile-back" onClick={()=>setMobilePanel("chat")}>‹</button><h2>Members <small>{memberPeople.length}</small></h2></header><p className="eyebrow">IN THIS CHAT</p>
      <div className="member-list">{memberPeople.map(p=><button key={p.uid}><Avatar person={p}/><span><b>{p.displayName}{p.uid===user.uid?" (You)":""}</b><small>Member</small></span></button>)}</div>
      <button className="invite" onClick={()=>setModal("people")}>＋ Start a direct message</button><div className="details-card"><h3>Conversation details</h3><p>Messages and photos synchronise in real time through Firebase.</p><div><span><b>{messages.filter(m=>m.imageUrl||m.fileUrl).length}</b> Media</span><span><b>{messages.length}</b> Messages</span></div></div>
    </aside>
    {modal&&<div className="modal-backdrop" onMouseDown={()=>setModal(null)}><section className="modal" onMouseDown={e=>e.stopPropagation()}><header><div><p className="eyebrow">CHATTERBOX</p><h2>{modal==="new"?"Create a group":modal==="people"?"Find people":"Add to your story"}</h2></div><button onClick={()=>setModal(null)}>×</button></header>
      {modal==="story"?<label className="story-upload">＋<b>Choose a photo</b><span>Visible for 24 hours</span><input type="file" accept="image/*" onChange={e=>e.target.files?.[0]&&upload(e.target.files[0],true)}/></label>:<>{modal==="new"&&<input className="modal-input" value={groupName} onChange={e=>setGroupName(e.target.value)} placeholder="Group name"/>}
      <div className="people-picker">{people.length===0&&<p className="no-people">Other users appear after they create an account.</p>}{people.map(p=><button key={p.uid} onClick={()=>modal==="people"?startDm(p):setSelectedPeople(s=>s.includes(p.uid)?s.filter(x=>x!==p.uid):[...s,p.uid])}><Avatar person={p}/><span><b>{p.displayName}</b><small>{p.email}</small></span>{modal==="new"&&<i className={selectedPeople.includes(p.uid)?"checked":""}>{selectedPeople.includes(p.uid)?"✓":""}</i>}</button>)}</div>{modal==="new"&&<button className="modal-primary" onClick={createGroup} disabled={!groupName.trim()}>Create group</button>}</>}</section></div>}
    {storyView&&<div className="story-view" onClick={()=>setStoryView(null)}><button>×</button><div className="story-author"><Avatar person={{uid:storyView.authorId,displayName:storyView.authorName,email:storyView.authorId}}/><b>{storyView.authorName}</b></div><img src={storyView.imageUrl} alt="Story"/></div>}
    {(notice||error)&&<div className="notice"><span>{notice||error}</span><button onClick={()=>{setNotice("");setError("")}}>×</button></div>}
    <CallSystem user={user} request={callRequest} onRequestHandled={()=>setCallRequest(null)}/>
  </main>;
}

function Avatar({person}:{person:Person}){return person.photoURL?<span className="avatar photo"><img src={person.photoURL} alt=""/></span>:<span className="avatar" style={{"--hue":hue(person.uid)} as React.CSSProperties}>{initials(person.displayName)}</span>}
function Logo(){return <span className="brand-mark"><i/><i/></span>}
function SetupNeeded(){return <div className="setup-screen"><Logo/><h1>Connect Firebase</h1><p>This build is ready. Copy <code>.env.example</code> to <code>.env</code> and add the configuration from your Firebase web app.</p><ol><li>Create a Firebase project and web app.</li><li>Enable Email/Password and Google sign-in.</li><li>Create Firestore and Storage.</li><li>Deploy the included security rules and Hosting files.</li></ol></div>}
